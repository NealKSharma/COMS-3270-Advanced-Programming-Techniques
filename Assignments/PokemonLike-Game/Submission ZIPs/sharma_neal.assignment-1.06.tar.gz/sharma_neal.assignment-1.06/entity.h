#ifndef ENTITY_H
#define ENTITY_H

#include <limits.h>

#include "map.h"

typedef enum {
    player, hiker, rival, pacer, wanderer, sentry, explorer
} entityType;

class Entity {
    public:
    int y, x;
    char standingOn, direction; // n, s, w, e
    entityType type;
    int isDefeated; // 0 for alive, 1 for defeated

    Entity() : y(0), x(0), standingOn(' '), direction('n'), type(player), isDefeated(0) {}
    virtual ~Entity() {}
};

class Player : public Entity {
    public:
    Player() {type = player;}
};

class NPC : public Entity {
    public:
    NPC() {}
};

struct heapNode{
    int y, x;
    int distance;
    Entity *e;
};

struct heap{
    heapNode *nodes;
    int size, capacity;
};

extern int hikerDistance[maxY][maxX];
extern int rivalDistance[maxY][maxX];

void pathFinding(singleMap *map, Player *pc, entityType type, int dist[maxY][maxX]);
int getCost(entityType type, char terrain);
void initializePlayer(Player *pc, singleMap *map);
void initializeEntities(singleMap *map, int numTrainers);
int isCellOccupiedByNPC(Entity **entityList, int numTrainers, int y, int x, Entity *self);

void displayBattle(Entity *npc);
void displayBuilding(char type);
void displayTrainers(Entity **list, int numTrainers, Player *pc);

void heapInitialize(heap *h);
void heapPush(heap *h, Entity *e, int y, int x, int distance);
heapNode heapPop(heap *h);

#endif
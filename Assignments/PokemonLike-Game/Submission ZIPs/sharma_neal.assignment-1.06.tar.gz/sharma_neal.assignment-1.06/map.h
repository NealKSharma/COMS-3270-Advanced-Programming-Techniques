#ifndef MAP_H
#define MAP_H

#include <stdlib.h>

#define maxY 21
#define maxX 80

class Entity;
struct heap;

class singleMap {
    public:
    int mapY, mapX, nGate, sGate, eGate, wGate;
    Entity **entityList;
    heap *turnQueue;
    char terrain[maxY][maxX];

    singleMap();
    ~singleMap();
};

struct queueNode{
    int x, y;
};

void setupMap(singleMap *map);
void renderMap(singleMap *map);
void generatePaths(singleMap *map, int n, int s, int w, int e);
void generateBuildings(singleMap *map, char pokeMart, char pokeCentre);
void generateTerrain(singleMap *map);
void addToQueue(singleMap *map, int nextX, int nextY, int currentX, int currentY, queueNode queue[], int *tail);

#endif
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <curses.h>
#include "entity.h"
#include "map.h"

int hikerDistance[maxY][maxX];
int rivalDistance[maxY][maxX];

static const int move_costs[7][8] = {
    // Terrain: 0:#, 1:M, 2:C, 3::, 4:., 5:^, 6:*, 7:Default
    {5, 30, 30, 15, 10, 20, 15, INT_MAX}, // Player
    {10, 50, 50, 15, 10, 15, 15, INT_MAX}, // Hiker
    {10, 50, 50, 20, 10, INT_MAX, 15, INT_MAX}, // Rival
    {5, 20, 20, 10, 5, INT_MAX, 10, INT_MAX}, // Pacer
    {10, 50, 50, 15, 10, INT_MAX, 10, INT_MAX}, // Wanderer
    {10, 50, 50, 20, 10, INT_MAX, 15, INT_MAX}, // Sentry (Doesn't really do anything)
    {10, 50, 50, 15, 15, INT_MAX, 10, INT_MAX} // Explorer
};

int getCost(entityType type, char terrain) {
    int terrainIndex;
    // Map the character to a column index
    switch(terrain) {
        case '#': terrainIndex = 0; break; // Path
        case 'M': terrainIndex = 1; break; // Pokemart
        case 'C': terrainIndex = 2; break; // Pokecenter
        case ':': terrainIndex = 3; break; // Tall Grass
        case '.': terrainIndex = 4; break; // Clearing
        case '^': terrainIndex = 5; break; // Trees
        case '*': terrainIndex = 6; break; // Flower
        default:  terrainIndex = 7; break; // INT_MAX
    }

    if (type < 0 || type > 6) return INT_MAX;
    return move_costs[type][terrainIndex];
}

void initializePlayer(Player *pc, singleMap *map){
    pc->type = player;
    // Can only be placed on a path
    int y, x;
    while(1){
        y = rand() % (maxY - 2) + 1;
        x = rand() % (maxX - 2) + 1;
        if(map->terrain[y][x] == '#'){
            pc->y = y;
            pc->x = x;
            pc->standingOn = map->terrain[y][x];
            map->terrain[y][x] = '@';
            break;
        }
    }
}

void displayBattle(Entity *npc){
    const char *name;
    switch (npc->type) {
        case hiker: name = "Hiker";    break;
        case rival: name = "Rival";    break;
        case pacer: name = "Pacer";    break;
        case wanderer: name = "Wanderer"; break;
        case sentry: name = "Sentry";   break;
        case explorer: name = "Explorer"; break;
        default: name = "Trainer";  break;
    }

    bkgd(COLOR_PAIR(1));
    clear();
    attrset(COLOR_PAIR(1));
    mvprintw(10, 30, "A %s challenges you!", name);
    mvprintw(12, 30, "Press ESC to win the battle."); // Placeholder
    refresh();
    while (getch() != 27);
    npc->isDefeated = 1;
    bkgd(COLOR_PAIR(1));
    clear();
}

void displayBuilding(char type) {
    bkgd(COLOR_PAIR(1));
    clear();
    attrset(COLOR_PAIR(1));
    mvprintw(10, 30, "Welcome to the %s!", (type == 'M' ? "Pokemart" : "Pokecenter"));
    mvprintw(12, 30, "Press < to leave."); // Placeholder
    refresh();
    while (getch() != '<');
    bkgd(COLOR_PAIR(1));
    clear();
}

void displayTrainers(Entity **list, int numTrainers, Player *pc) {
    int quit = 0, scroll_offset = 0;
    while (!quit) {
        bkgd(COLOR_PAIR(1));
        clear();
        attrset(COLOR_PAIR(1));
        mvprintw(0, 0, "%-5s | %-20s", "Type", "Relative Position");
        mvprintw(1, 0, "------------------------------------");

        for (int i = 0; i < 20 && (i + scroll_offset) < numTrainers; i++) {
            Entity *e = list[i + scroll_offset];
            int distY = pc->y - e->y; // Positive = NPC is North of PC
            int distX = pc->x - e->x; // Positive = NPC is West of PC

            mvprintw(i + 2, 0, "%c     | %d %s and %d %s", "@hrpwse"[e->type],
                     abs(distY), (distY >= 0 ? "North" : "South"),
                     abs(distX), (distX >= 0 ? "West" : "East"));
        }
        refresh();
        int ch = getch();
        switch(ch) {
            case 27: quit = 1; break;
            case KEY_UP: if (scroll_offset > 0) scroll_offset--; break;
            case KEY_DOWN: if (scroll_offset < numTrainers - 20) scroll_offset++; break;
        }
    }
}

void pathFinding(singleMap *map, Player *pc, entityType type, int dist[maxY][maxX]){
    heap h;
    heapInitialize(&h);

    for(int i = 0; i < maxY; i++){
        for(int j = 0; j < maxX; j++){
            dist[i][j] = INT_MAX; // Set distances to Int Max.
        }
    }
    // Set player's location to 0 distance.
    dist[pc->y][pc->x] = 0;
    heapPush(&h, nullptr, pc->y, pc->x, 0);

    while(h.size > 0){
        heapNode curr = heapPop(&h);
        if(curr.distance > dist[curr.y][curr.x]) continue;

        // Check the different directions
        for(int dy = -1; dy <= 1; dy++){
            for (int dx = -1; dx <= 1; dx++){
                if(dy == 0 && dx == 0) continue; // Skip the current tile
                int neighborY = curr.y + dy;
                int neighborX = curr.x + dx;

                if(neighborY > 0 && neighborY < maxY - 1 && neighborX > 0 && neighborX < maxX - 1){
                    char terrain = map->terrain[neighborY][neighborX];
                    int moveCost = getCost(type, terrain);
                    if(moveCost != INT_MAX){
                        int newDist = dist[curr.y][curr.x] + moveCost;
                        if(newDist < dist[neighborY][neighborX]){
                            dist[neighborY][neighborX] = newDist;
                            heapPush(&h, nullptr, neighborY, neighborX, newDist);
                        }
                    }
                }
            }
        }
    }
    free(h.nodes);
}

static void placeEntity(singleMap *map, entityType type, int index){
    NPC *npc = new NPC();
    int y = rand() % (maxY - 2) + 1;
    int x = rand() % (maxX - 2) + 1;
    while(getCost(type, map->terrain[y][x]) == INT_MAX || map->terrain[y][x] == 'M' || map->terrain[y][x] == 'C'){
        y = rand() % (maxY - 2) + 1;
        x = rand() % (maxX - 2) + 1;
    }
    npc->y = y;
    npc->x = x;
    npc->type = type;
    npc->standingOn = map->terrain[y][x];
    char dirs[] = {'n', 's', 'e', 'w'};
    npc->direction = dirs[rand() % 4];
    npc->isDefeated = 0;
    switch(type){
        case 1: map->terrain[y][x] = 'h'; break;
        case 2: map->terrain[y][x] = 'r';break;
        case 3: map->terrain[y][x] = 'p';break;
        case 4: map->terrain[y][x] = 'w';break;
        case 5: map->terrain[y][x] = 's';break;
        case 6: map->terrain[y][x] = 'e';break;
        default: break;
    }
    map->entityList[index] = npc;
}

void initializeEntities(singleMap *map, int numTrainers){
    map->entityList = nullptr;
    if (numTrainers <= 0) return;

    map->entityList = (Entity **)malloc(numTrainers * sizeof(Entity *));
    if(!map->entityList) return;

    int index = 0;
    if (numTrainers < 2) {
        if(rand() % 2 == 0) placeEntity(map, hiker, index++);
        else placeEntity(map, rival, index++);
    } else {
        placeEntity(map, hiker, index++);
        placeEntity(map, rival, index++);
        numTrainers -= 2;
        while(numTrainers > 0){
            entityType type = (entityType)(1 + rand() % 6);
            placeEntity(map, type, index++);
            numTrainers--;
        }
    }
}

int isCellOccupiedByNPC(Entity **entityList, int numTrainers, int y, int x, Entity *self) {
    for (int i = 0; i < numTrainers; i++) {
        Entity *other = (Entity *)entityList[i];
        if (other == self) continue; // Ignore if self
        if (other->y == y && other->x == x) return 1;
    }
    return 0;
}

void heapInitialize(heap *h){
    h->capacity = 256; // Is increased further
    h->size = 0;
    h->nodes = (heapNode *)malloc(sizeof(heapNode) * h->capacity);
}

void heapPush(heap *h, Entity *e, int y, int x, int distance){
    if (h->size >= h->capacity) {
        h->capacity *= 2;
        h->nodes = (heapNode *)realloc(h->nodes, sizeof(heapNode) * h->capacity);
    }

    int i = h->size++;
    while(i > 0 && h->nodes[(i - 1) / 2].distance > distance){
        h->nodes[i] = h->nodes[(i - 1) / 2];
        i = (i - 1) / 2;
    }
    h->nodes[i].y = y;
    h->nodes[i].x = x;
    h->nodes[i].e = e;
    h->nodes[i].distance = distance;
}

heapNode heapPop(heap *h) {
    heapNode min = h->nodes[0];
    h->size--; 
    
    if (h->size > 0) {
        heapNode last = h->nodes[h->size];
        int i = 0, child;
        while ((child = i * 2 + 1) < h->size) {
            if (child + 1 < h->size && h->nodes[child + 1].distance < h->nodes[child].distance) {
                child++;
            }
            if (last.distance <= h->nodes[child].distance) break;
            h->nodes[i] = h->nodes[child];
            i = child;
        }
        h->nodes[i] = last;
    }
    return min;
}
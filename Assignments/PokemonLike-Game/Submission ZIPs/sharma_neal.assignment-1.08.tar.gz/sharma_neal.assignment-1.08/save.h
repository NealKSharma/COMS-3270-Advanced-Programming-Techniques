#ifndef SAVE_H
#define SAVE_H

#include <string>
#include <vector>
#include <climits>
#include <iostream>
#include <fstream>
#include <cstdlib>

inline int toInt(const std::string &str){
    return str.empty() ? INT_MAX : std::stoi(str);
}

inline void printInt(int num, char comma = ','){
   if (num != INT_MAX) std::cout << num;
   std::cout << comma;
}

inline std::vector<std::string> parseLine(const std::string &line){
    std::vector<std::string> ret;
    std::string ch = "";
    for(std::size_t i = 0; i < line.length(); i++){
        if(line[i] == ','){
            ret.push_back(ch);
            ch = "";
        } else {
            ch += line[i];
        }
    }
    ret.push_back(ch);
    return ret;
}

class Pokemon {
    public:
     int id;
     std::string identifier;
     int species_id, height, weight, base_experience, order, is_default;

     Pokemon(std::vector<std::string> &row){
        id = toInt(row[0]);
        identifier = row[1];
        species_id = toInt(row[2]);
        height = toInt(row[3]); 
        weight = toInt(row[4]);
        base_experience = toInt(row[5]);
        order = toInt(row[6]);
        is_default = toInt(row[7]);
     }
};

class Moves {
    public:
     int id;
     std::string identifier;
     int generation_id, type_id, power, pp, accuracy, priority, target_id,damage_class_id, 
         effect_id, effect_chance, contest_type_id,contest_effect_id, super_contest_effect_id;

     Moves(std::vector<std::string> &row){
        id = toInt(row[0]);
        identifier = row[1];
        generation_id = toInt(row[2]);
        type_id = toInt(row[3]);
        power = toInt(row[4]);
        pp = toInt(row[5]);
        accuracy = toInt(row[6]);
        priority = toInt(row[7]);
        target_id = toInt(row[8]);
        damage_class_id = toInt(row[9]);
        effect_id = toInt(row[10]);
        effect_chance = toInt(row[11]);
        contest_type_id = toInt(row[12]);
        contest_effect_id = toInt(row[13]);
        super_contest_effect_id = toInt(row[14]);
     }
};

class Pokemon_Moves {
    public:
     int pokemon_id, version_group_id, move_id, pokemon_move_method_id, level, order;

     Pokemon_Moves(std::vector<std::string> &row){
        pokemon_id = toInt(row[0]);
        version_group_id = toInt(row[1]);
        move_id = toInt(row[2]);
        pokemon_move_method_id = toInt(row[3]);
        level = toInt(row[4]);
        order = toInt(row[5]);
     }
};

class Pokemon_Species {
    public:
     int id;
     std::string identifier;
     int generation_id, evolves_from_species_id, evolution_chain_id, color_id, shape_id, habitat_id, gender_rate,
         capture_rate, base_happiness, is_baby, hatch_counter, has_gender_differences, growth_rate_id, forms_switchable,
         is_legendary, is_mythical, order, conquest_order;

     Pokemon_Species(std::vector<std::string> &row){
        id = toInt(row[0]);
        identifier = row[1];
        generation_id = toInt(row[2]);
        evolves_from_species_id = toInt(row[3]);
        evolution_chain_id = toInt(row[4]);
        color_id = toInt(row[5]);
        shape_id = toInt(row[6]);
        habitat_id = toInt(row[7]);
        gender_rate = toInt(row[8]);
        capture_rate = toInt(row[9]);
        base_happiness = toInt(row[10]);
        is_baby = toInt(row[11]);
        hatch_counter = toInt(row[12]);
        has_gender_differences = toInt(row[13]);
        growth_rate_id = toInt(row[14]);
        forms_switchable = toInt(row[15]);
        is_legendary = toInt(row[16]);
        is_mythical = toInt(row[17]);
        order = toInt(row[18]);
        conquest_order = toInt(row[19]);
     }
};

class Experience {
    public:
     int growth_rate_id, level, experience;

     Experience(std::vector<std::string> &row){
        growth_rate_id = toInt(row[0]);
        level = toInt(row[1]);
        experience = toInt(row[2]);
     }
};

class Type_Names {
    public:
     int type_id, local_language_id;
     std::string name;

     Type_Names(std::vector<std::string> &row){
        type_id = toInt(row[0]);
        local_language_id = toInt(row[1]);
        name = row[2];
     }
};

class Pokemon_Stats {
    public:
     int pokemon_id, stat_id, base_stat, effort;

     Pokemon_Stats(std::vector<std::string> &row){
        pokemon_id = toInt(row[0]);
        stat_id = toInt(row[1]);
        base_stat = toInt(row[2]);
        effort = toInt(row[3]);
     }
};

class Stats {
    public:
     int id, damage_class_id;
     std::string identifier;
     int is_battle_only, game_index;

     Stats(std::vector<std::string> &row){
        id = toInt(row[0]);
        damage_class_id = toInt(row[1]);
        identifier = row[2];
        is_battle_only = toInt(row[3]);
        game_index = toInt(row[4]);
     }
};

class Pokemon_Types {
    public:
     int pokemon_id, type_id, slot;

     Pokemon_Types(std::vector<std::string> &row){
        pokemon_id = toInt(row[0]);
        type_id = toInt(row[1]);
        slot = toInt(row[2]);
     }
};

template <typename T>
std::vector<T> parseFile(std::string name){
    std::string filePaths[2] = {"/share/cs327/pokedex/pokedex/data/csv/", std::string(getenv("HOME")) + "/.poke327/pokedex/pokedex/data/csv/"};

    for(std::size_t i = 0; i < sizeof(filePaths) / sizeof(filePaths[0]); i++){
        std::ifstream file;
        file.open(filePaths[i] + name + ".csv");
        if(file.is_open()){
            std::vector<T> data;
            std::string line;
            getline(file, line); // To skip the header

            while(getline(file, line)){
                std::vector<std::string> row = parseLine(line);
                data.push_back(T(row));
            }
            return data;
        }
    }
    fprintf(stderr, "Error: Could not find %s.csv\n", name.c_str());
    exit(1);
}

#endif
#ifndef ENTITY_H
#define ENTITY_H

#include <limits.h>
#include <vector>
#include <string>

#include "map.h"
#include "save.h"

extern std::vector<Pokemon> all_pokemon;
extern std::vector<Moves> all_moves;
extern std::vector<Pokemon_Moves> all_pokemon_moves;
extern std::vector<Pokemon_Stats> all_pokemon_stats;

class SinglePokemon {
public:
    int species_id;
    std::string name;
    int level;
    int ivs[6];   // HP, Atk, Def, SpAtk, SpDef, Speed
    int stats[6]; // Resulting stats
    int moves[2];
    int current_hp;
    bool shiny;
    bool gender; // 0: Male, 1: Female

    SinglePokemon(int level);
    void calculateStats();
};

typedef enum {
    player, hiker, rival, pacer, wanderer, sentry, explorer
} entityType;

class Entity {
    public:
    int y, x;
    char standingOn, direction; // n, s, w, e
    entityType type;
    int isDefeated; // 0 for alive, 1 for defeated
    std::vector<SinglePokemon*> party;

    Entity() : y(0), x(0), standingOn(' '), direction('n'), type(player), isDefeated(0) {}
    virtual ~Entity() {
        for (auto p : party) delete p;
    }
};

class Player : public Entity {
    public:
    Player() {type = player;}
};

class NPC : public Entity {
    public:
    NPC() {}
};

struct heapNode{
    int y, x;
    int distance;
    Entity *e;
};

struct heap{
    heapNode *nodes;
    int size, capacity;
};

extern int hikerDistance[maxY][maxX];
extern int rivalDistance[maxY][maxX];

int calculateLevel(int dist);
void selectStarter(Player *pc);
void displayEncounter(SinglePokemon *pk);
void initializeEntities(singleMap *map, int numTrainers, int locationX, int locationY);

void pathFinding(singleMap *map, Player *pc, entityType type, int dist[maxY][maxX]);
int getCost(entityType type, char terrain);
void initializePlayer(Player *pc, singleMap *map);
int isCellOccupiedByNPC(Entity **entityList, int numTrainers, int y, int x, Entity *self);

void displayBattle(Entity *npc);
void displayBuilding(char type);
void displayTrainers(Entity **list, int numTrainers, Player *pc);

void heapInitialize(heap *h);
void heapPush(heap *h, Entity *e, int y, int x, int distance);
heapNode heapPop(heap *h);

#endif
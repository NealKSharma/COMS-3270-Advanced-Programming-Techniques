#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <curses.h>

#include "map.h"
#include "entity.h"

typedef struct {
    singleMap *world[401][401];
    int x, y, numTrainers;
    Player *pc;
} Game;

void generateMap(Game *game){
    setupMap(game->world[game->y][game->x]);

    // Either coordinate of the connecting gate / -1 for randomly generated gate / -2 for no gate (Gates cant be at a -ve value)
    int n = (game->y > 0 && game->world[game->y-1][game->x] != NULL) ? game->world[game->y-1][game->x]->sGate : -1;
    int s = (game->y < 400 && game->world[game->y+1][game->x] != NULL) ? game->world[game->y+1][game->x]->nGate : -1;
    int w = (game->x > 0 && game->world[game->y][game->x-1] != NULL) ? game->world[game->y][game->x-1]->eGate : -1;
    int e = (game->x < 400 && game->world[game->y][game->x+1] != NULL) ? game->world[game->y][game->x+1]->wGate : -1;
    // If the map is on the border dont generate gates at all
    if(game->y == 0) n = -2; 
    if(game->y == 400) s = -2;
    if (game->x == 0) w = -2;
    if (game->x == 400) e = -2;
    generatePaths(game->world[game->y][game->x], n, s, w, e);

    int distance = abs(game->x - 200) + abs(game->y - 200);
    int probability = 5; // Default value is 5%
    if(distance < 200) probability = ((-45 * distance) / 200) + 50;
    char pokeMart = ((rand() % 100) < probability || (game->x == 200 && game->y == 200)) ? 'M' : ' ';
    char pokeCentre = ((rand() % 100) < probability || (game->x == 200 && game->y == 200)) ? 'C' : ' ';
    generateBuildings(game->world[game->y][game->x], pokeMart, pokeCentre);

    generateTerrain(game->world[game->y][game->x]);
    initializePlayer(game->pc, game->world[game->y][game->x]);
    initializeEntities(game->world[game->y][game->x], game->numTrainers);
}

void runGame(Game *game, heap *h, singleMap *currMap) {
    int quit = 0;
    while (!quit) {
        heapNode top = heapPop(h);
        Entity *e = top.e;
        int nextY = e->y;
        int nextX = e->x;

        if (e->type == player) {
            renderMap(currMap);
            int turn_done = 0;
            char msg[128];
            snprintf(msg, sizeof(msg), "Location: (%d, %d) | [Q]uit [t]rainers [>]enter", game->x-200, game->y-200);
            
            while (!turn_done) {
                move(0, 0); 
                clrtoeol();
                mvprintw(0, 0, "%s", msg);
                snprintf(msg, sizeof(msg), "Location: (%d, %d) | [Q]uit [t]rainers [>]enter", game->x-200, game->y-200);

                int ch = getch();
                int tempY = 0, tempX = 0;

                switch(ch) {
                    case 'Q': quit = 1; turn_done = 1; break;
                    case '7': case 'y': tempY = -1; tempX = -1; break;
                    case '8': case 'k': tempY = -1; tempX = 0;  break;
                    case '9': case 'u': tempY = -1; tempX = 1;  break;
                    case '6': case 'l': tempY = 0;  tempX = 1;  break;
                    case '3': case 'n': tempY = 1;  tempX = 1;  break;
                    case '2': case 'j': tempY = 1;  tempX = 0;  break;
                    case '1': case 'b': tempY = 1;  tempX = -1; break;
                    case '4': case 'h': tempY = 0;  tempX = -1; break;
                    case '5': case ' ': case '.': turn_done = 1; break;
                    case 't':
                        displayTrainers((Entity **)currMap->entityList, game->numTrainers, game->pc);
                        renderMap(currMap);
                        break;
                    case '>':
                        if (e->standingOn == 'M' || e->standingOn == 'C') {
                            displayBuilding(e->standingOn);
                            renderMap(currMap);
                        } else {
                            snprintf(msg, sizeof(msg), "Not standing on a building!");
                        }
                        break;
                }

                if (tempY != 0 || tempX != 0) {
                    int newY = e->y + tempY;
                    int newX = e->x + tempX;
                    if (newY <= 0 || newY >= maxY - 1 || newX <= 0 || newX >= maxX - 1) {
                        snprintf(msg, sizeof(msg), "The border is impassable!");
                    } else {
                        Entity *target = NULL;
                        for (int i = 0; i < game->numTrainers; i++) {
                            if (currMap->entityList[i]->y == newY && currMap->entityList[i]->x == newX) {
                                target = (Entity *)currMap->entityList[i];
                            }
                        }

                        if (target != NULL) {
                            if (!target->isDefeated) {
                                displayBattle(target);
                                renderMap(currMap);
                            }
                            turn_done = 1;
                        } else if (getCost(player, currMap->terrain[newY][newX]) == INT_MAX) {
                            snprintf(msg, sizeof(msg), "The terrain is impassable!");
                        } else {
                            nextY = newY; 
                            nextX = newX;
                            turn_done = 1;
                        }
                    }
                }
            }
            if (quit) break;
            // Update NPC Pathfinding after player moves
            pathFinding(currMap, game->pc, hiker, hikerDistance);
            pathFinding(currMap, game->pc, rival, rivalDistance);
            
        } else {           
            // Defeated Hikers and Rivals stop pathing to the PC
            if (e->isDefeated && (e->type == hiker || e->type == rival)) {
                nextY = e->y; 
                nextX = e->x; 
            } else {
                switch (e->type) {
                    case hiker:
                    case rival: {
                        int minDist = INT_MAX;
                        int tempY, tempX;
                        // Check all 8 neighbors in the distance maps
                        for (int moveY = -1; moveY <= 1; moveY++) {
                            for (int moveX = -1; moveX <= 1; moveX++) {
                                if (moveY == 0 && moveX == 0) continue;
                                tempY = e->y + moveY;
                                tempX = e->x + moveX;

                                // Check for the border (this includes gates)
                                if (tempY <= 0 || tempY >= maxY - 1 || tempX <= 0 || tempX >= maxX - 1) continue;

                                int d = (e->type == hiker) ? hikerDistance[tempY][tempX] : rivalDistance[tempY][tempX];
                                if (d < minDist) {
                                    minDist = d;
                                    nextY = tempY;
                                    nextX = tempX;
                                }
                            }
                        }
                        break;
                    }

                    case pacer: {
                        int moveY = (e->direction == 'n') ? -1 : (e->direction == 's') ? 1 : 0;
                        int moveX = (e->direction == 'w') ? -1 : (e->direction == 'e') ? 1 : 0;
                        
                        // Check boundary, terrain cost, and gate rules
                        if (e->y + moveY <= 0 || e->y + moveY >= maxY - 1 || 
                            e->x + moveX <= 0 || e->x + moveX >= maxX - 1 ||
                            getCost(pacer, currMap->terrain[e->y + moveY][e->x + moveX]) == INT_MAX) {
                            // Reverse direction
                            if (e->direction == 'n') e->direction = 's';
                            else if (e->direction == 's') e->direction = 'n';
                            else if (e->direction == 'e') e->direction = 'w';
                            else e->direction = 'e';
                        }
                        nextY = e->y + ((e->direction == 'n') ? -1 : (e->direction == 's') ? 1 : 0);
                        nextX = e->x + ((e->direction == 'w') ? -1 : (e->direction == 'e') ? 1 : 0);
                        break;
                    }

                    case wanderer:
                    case explorer: {
                        int moveY = (e->direction == 'n') ? -1 : (e->direction == 's') ? 1 : 0;
                        int moveX = (e->direction == 'w') ? -1 : (e->direction == 'e') ? 1 : 0;
                        char dirs[] = {'n', 's', 'e', 'w'};
                        int attempts = 0;
                        while (attempts++ < 12) {
                            moveY = (e->direction == 'n') ? -1 : (e->direction == 's') ? 1 : 0;
                            moveX = (e->direction == 'w') ? -1 : (e->direction == 'e') ? 1 : 0;
                            char newTerrain = currMap->terrain[e->y + moveY][e->x + moveX];
                            int tempY = e->y + moveY;
                            int tempX = e->x + moveX;
                            if (tempY > 0 && tempY < maxY-1 && tempX > 0 && tempX < maxX-1 &&
                                getCost(e->type, newTerrain) != INT_MAX &&
                                (e->type != wanderer || newTerrain == e->standingOn || newTerrain == '@')) {
                                nextY = tempY; nextX = tempX;
                                break;
                            }
                            e->direction = dirs[rand() % 4];
                        }
                        break;
                    }

                    case sentry:
                        nextY = e->y;
                        nextX = e->x;
                        break;

                    default: break;
                }
            }
            
            // Collision with player
            if (nextY == game->pc->entity.y && nextX == game->pc->entity.x) {
                if (!e->isDefeated) {
                    displayBattle(e); 
                    renderMap(currMap);
                }
                nextY = e->y; nextX = e->x; // Revert
            }
            // Collision with NPC
            else if (isCellOccupiedByNPC((Entity **)currMap->entityList, game->numTrainers, nextY, nextX, e)) {
                nextY = e->y; nextX = e->x; // Revert
            }
        }

        // Update Map and Re-heap
        currMap->terrain[e->y][e->x] = e->standingOn;
        e->y = nextY;
        e->x = nextX;
        e->standingOn = currMap->terrain[e->y][e->x];
        char symbols[] = {'@', 'h', 'r', 'p', 'w', 's', 'e'};
        currMap->terrain[e->y][e->x] = symbols[e->type];
        int cost = getCost(e->type, e->standingOn);
        heapPush(h, e, e->y, e->x, top.distance + cost);
    }
}

int main(int argc, char *argv[]){
    initscr();
    set_escdelay(0);
    raw();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);

    srand(time(NULL));

    Game *game = calloc(1, sizeof(Game)); 
    game->y = 200;
    game->x = 200;
    game->numTrainers = 10;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--numtrainers") == 0 && i + 1 < argc) {
            game->numTrainers = atoi(argv[++i]);
        }
    }

    if (has_colors()) {
        start_color();
        init_pair(1, COLOR_WHITE, COLOR_BLACK); // Path #, Flowers *
        init_pair(2, COLOR_GREEN, COLOR_BLACK); // Tall grass :
        init_pair(3, COLOR_BLUE, COLOR_BLACK);  // Water ~
        init_pair(4, COLOR_WHITE, COLOR_RED); // Buildings M / C
        init_pair(5, COLOR_MAGENTA, COLOR_BLACK); // boulders %
        init_pair(6, COLOR_YELLOW, COLOR_BLACK); // Trainers h/r/p/w/s/e
        init_pair(7, COLOR_GREEN, COLOR_BLACK); // Trees ^
        init_pair(8, COLOR_YELLOW, COLOR_BLACK); // Clearing .
        init_pair(9, COLOR_WHITE, COLOR_GREEN); // Player @
        bkgd(COLOR_PAIR(1));
    }

    // Generate the initial map and entities
    game->pc = malloc(sizeof(Player));
    game->world[game->y][game->x] = malloc(sizeof(singleMap));
    generateMap(game);

    heap h;
    heapInitialize(&h);
    singleMap *currMap = game->world[game->y][game->x];

    pathFinding(currMap, game->pc, hiker, hikerDistance);
    pathFinding(currMap, game->pc, rival, rivalDistance);

    heapPush(&h, &game->pc->entity, game->pc->entity.y, game->pc->entity.x, 0);
    for (int i = 0; i < game->numTrainers; i++) {
        Entity *npc = (Entity *)currMap->entityList[i];
        heapPush(&h, npc, npc->y, npc->x, 0);
    }

    runGame(game, &h, currMap);

    for (int i = 0; i < 401; i++){
        for(int j = 0; j < 401; j++){
            if(game->world[i][j] == NULL) continue;
            if (game->numTrainers > 0) {
                for(int k = 0; k < game->numTrainers; k++){
                    free(game->world[i][j]->entityList[k]);
                }
                free(game->world[i][j]->entityList);
            }
            free(game->world[i][j]);
        }
    }

    free(h.nodes);
    free(game->pc);
    free(game);

    endwin();
    echo();
    curs_set(1);

    return 0;
}
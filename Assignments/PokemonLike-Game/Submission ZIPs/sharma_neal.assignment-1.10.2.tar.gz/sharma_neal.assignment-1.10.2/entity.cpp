#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <curses.h>
#include <iostream>

#include "entity.h"
#include "map.h"

int hikerDistance[maxY][maxX];
int rivalDistance[maxY][maxX];

SinglePokemon::SinglePokemon(int lvl) : level(lvl) {
    int index = rand() % all_pokemon.size();
    species_id = all_pokemon[index].species_id;
    name = all_pokemon[index].identifier;
    shiny = (rand() % 8192 == 0);
    gender = (rand() % 2 == 0);

    for (int i = 0; i < 6; i++) ivs[i] = rand() % 16;

    std::vector<int> possible;
    for (auto &m : all_pokemon_moves) {
        if (m.pokemon_id == species_id && m.pokemon_move_method_id == 1 && m.level <= level) {
            bool found = false;
            for (int id : possible) if (id == m.move_id) { found = true; break; }
            if (!found) possible.push_back(m.move_id);
        }
    }

    while (possible.empty() && level < 100) {
        level++;
        possible.clear();
        for (auto &m : all_pokemon_moves) {
            if (m.pokemon_id == species_id && m.pokemon_move_method_id == 1 && m.level <= level) {
                bool found = false;
                for (int id : possible) if (id == m.move_id) { found = true; break; }
                if (!found) possible.push_back(m.move_id);
            }
        }
    }

    if (possible.empty()) {
        moves[0] = 165;
        moves[1] = -1;
    } else if (possible.size() == 1) {
        moves[0] = possible[0];
        moves[1] = -1;
    } else {
        int index1 = rand() % possible.size();
        int index2 = rand() % (possible.size() - 1);
        if (index2 >= index1) index2++;
        moves[0] = possible[index1];
        moves[1] = possible[index2];
    }

    calculateStats();
}

SinglePokemon::SinglePokemon() : species_id(0), name(""), level(1), current_hp(0), shiny(false), gender(false) {
    for (int i = 0; i < 6; i++) ivs[i] = stats[i] = 0;
    moves[0] = moves[1] = -1;
}

void SinglePokemon::calculateStats() {
    int base[6] = {10, 10, 10, 10, 10, 10}; 
    for (auto &ps : all_pokemon_stats) {
        if (ps.pokemon_id == species_id && ps.stat_id <= 6)
            base[ps.stat_id - 1] = ps.base_stat;
    }

    stats[0] = ((2 * base[0] + ivs[0]) * level) / 100 + level + 10;
    current_hp = stats[0];
    for (int i = 1; i < 6; i++) {
        stats[i] = ((2 * base[i] + ivs[i]) * level) / 100 + 5;
    }
}

void selectStarter(Player *pc) {
    SinglePokemon* p[3] = { new SinglePokemon(1), new SinglePokemon(1), new SinglePokemon(1) };
    int selection = -1;
    while (selection < 0) {
        clear();
        mvprintw(2, 10, "PICK YOUR STARTER:");
        for(int i=0; i<3; i++) mvprintw(4+i, 12, "(%d) %s", i+1, p[i]->name.c_str());
        refresh();
        int c = getch();
        if (c >= '1' && c <= '3') selection = c - '1';
    }
    pc->party.push_back(p[selection]);
    for(int i=0; i<3; i++) if(i != selection) delete p[i];
}

int calculateLevel(int dist) {
    int min, max;
    if (dist <= 200) {
        min = 1;
        max = dist / 2;
    } else {
        min = (dist - 200) / 2;
        max = 100;
    }
    return (min >= max) ? min : (rand() % (max - min + 1)) + min;
}

void wait_for_key() {
    mvprintw(22, 2, "Press any key to continue...");
    refresh(); getch(); move(22, 0); clrtoeol(); refresh();
}

void battle_log(const char *msg) {
    move(7, 0);
    clrtoeol();
    if (msg && msg[0]) {
        mvprintw(7, 2, "%s", msg);
        wait_for_key();
    }
}

static void drawBattleScreen(SinglePokemon *enemy, const char *eLabel, SinglePokemon *yours, const char *msg) {
    bkgd(COLOR_PAIR(1)); clear(); attrset(COLOR_PAIR(1));
    
    // Enemy Info
    mvprintw(1, 2, "%-6s %-14s Lv.%-3d  HP: %d/%d", eLabel, enemy->name.c_str(), enemy->level, enemy->current_hp, enemy->stats[0]);
    int ebar = (enemy->stats[0] > 0) ? (20 * enemy->current_hp / enemy->stats[0]) : 0;
    mvprintw(2, 2, "[%-20.*s]", ebar, "====================");

    // Player Info
    mvprintw(4, 2, "Your:  %-14s Lv.%-3d  HP: %d/%d", yours->name.c_str(), yours->level, yours->current_hp, yours->stats[0]);
    int ybar = (yours->stats[0] > 0) ? (20 * yours->current_hp / yours->stats[0]) : 0;
    mvprintw(5, 2, "[%-20.*s]", ybar, "====================");

    if (msg && msg[0]) mvprintw(7, 2, "%s", msg);
    refresh();
}

static int pickParty(Player *pc, int current, bool force) {
    if (force) {
        bool anyAlive = false;
        for (auto *p : pc->party)
            if (p->current_hp > 0) { anyAlive = true; break; }
        if (!anyAlive) return -1;
    }
    while (true) {
        bkgd(COLOR_PAIR(1)); clear(); attrset(COLOR_PAIR(1));
        mvprintw(1, 2, "Switch Pokemon:");
        for (int i = 0; i < (int)pc->party.size(); i++) {
            SinglePokemon *p = pc->party[i];
            mvprintw(3 + i, 4, "%d. %-14s Lv.%-3d  HP:%d/%d%s%s", i + 1, p->name.c_str(), p->level, p->current_hp, p->stats[0], 
            i == current ? " <active>" : "", p->current_hp <= 0 ? " [KO]" : "");
        }
        if (!force) mvprintw(11, 4, "0. Back");
        refresh();
 
        int ch = getch();
        if (!force && ch == '0') return -1;
        int index = ch - '1';
        if (index < 0 || index >= (int)pc->party.size()) continue;
        if (pc->party[index]->current_hp <= 0) continue;
        if (!force && index == current) continue;
        return index;
    }
}

static int calcDamage(SinglePokemon *atk, SinglePokemon *def, int moveId) {
    Moves *mv = nullptr;
    for (auto &m : all_moves) if (m.id == moveId) { mv = &m; break; }
    if (!mv) return 1;

    if (rand() % 100 > ((mv->accuracy == INT_MAX) ? 100 : mv->accuracy)) return -1;

    int power = (mv->power == INT_MAX || mv->power <= 0) ? 1 : mv->power;
    int baseSpd = 45;
    for (auto &ps : all_pokemon_stats)
        if (ps.pokemon_id == atk->species_id && ps.stat_id == 6) baseSpd = ps.base_stat;

    float crit = (rand() % 256 < baseSpd / 2) ? 1.5f : 1.0f;
    float rnd  = (85 + rand() % 16) / 100.0f;
    float stab = 1.0f;
    for (auto &pt : all_pokemon_types)
        if (pt.pokemon_id == atk->species_id && pt.type_id == mv->type_id) stab = 1.5f;

    float dmg = ((2.0f * atk->level / 5.0f + 2.0f) * power * atk->stats[1] / (float)def->stats[2] / 50.0f + 2.0f) * crit * rnd * stab;
    return (int)dmg < 1 ? 1 : (int)dmg;
}

static int move_selection_menu(SinglePokemon *p) {
    while (true) {
        clear();
        mvprintw(1, 2, "Choose a move for %s:", p->name.c_str());
        for (int i = 0; i < 2; i++) {
            if (p->moves[i] == -1) continue;
            for (auto &mv : all_moves) {
                if (mv.id == p->moves[i])
                    mvprintw(3 + i, 4, "%d. %-18s Pwr:%-4d Acc:%d", i + 1, mv.identifier.c_str(), (mv.power == INT_MAX ? 0 : mv.power), (mv.accuracy == INT_MAX ? 100 : mv.accuracy));
            }
        }
        mvprintw(6, 4, "0. Back");
        int ch = getch();
        if (ch == '0') return -1;
        int idx = ch - '1';
        if (idx >= 0 && idx < 2 && p->moves[idx] != -1) return p->moves[idx];
    }
}

static int pickBagTarget(Player *pc, bool alive) {
    while (true) {
        bkgd(COLOR_PAIR(1)); clear(); attrset(COLOR_PAIR(1));
        mvprintw(1, 2, alive ? "Use on which Pokemon?" : "Revive which Pokemon?");
        bool anyValid = false;
        for (int i = 0; i < (int)pc->party.size(); i++) {
            SinglePokemon *p = pc->party[i];
            bool valid = alive ? (p->current_hp > 0) : (p->current_hp <= 0);
            if (valid) {
                mvprintw(3 + i, 4, "%d. %-14s  HP:%d/%d%s", i + 1, p->name.c_str(), p->current_hp, p->stats[0], p->current_hp <= 0 ? " [KO]" : "");
                anyValid = true;
            } else {
                mvprintw(3 + i, 4, "   %-14s  (unavailable)", p->name.c_str());
            }
        }
        mvprintw(11, 4, "0. Back");
        if (!anyValid) { mvprintw(7, 4, "No valid targets."); refresh(); getch(); return -1; }
        refresh();
 
        int ch = getch();
        if (ch == '0') return -1;
        int idx = ch - '1';
        if (idx < 0 || idx >= (int)pc->party.size()) continue;
        bool valid = alive ? (pc->party[idx]->current_hp > 0) : (pc->party[idx]->current_hp <= 0);
        if (!valid) continue;
        return idx;
    }
}

static int bag_battle_menu(Player *pc, bool isWild, SinglePokemon *enemy, SinglePokemon *activePokemon, char *msg) {
    while (true) {
        clear();
        mvprintw(1, 2, "Bag:");
        mvprintw(3, 4, "1. Potion (x%d)", pc->potions);
        mvprintw(4, 4, "2. Revive (x%d)", pc->revives);
        mvprintw(5, 4, "3. Pokeball (x%d) %s", pc->pokeballs, isWild ? "" : "[Cant use in Trainer Battles]");
        mvprintw(7, 4, "0. Back");
        
        int ch = getch();
        if (ch == '0') return 0;

        int result = 0;

        if (ch == '1' && pc->potions > 0) {
            int target = pickBagTarget(pc, true);
            if (target != -1) {
                pc->party[target]->current_hp = std::min(pc->party[target]->stats[0], pc->party[target]->current_hp + 20);
                pc->potions--;
                sprintf(msg, "Used Potion on %s!", pc->party[target]->name.c_str());
                result = 2; // Success
            }
        }
        else if (ch == '2' && pc->revives > 0) {
            int target = pickBagTarget(pc, false);
            if (target != -1) {
                pc->party[target]->current_hp = pc->party[target]->stats[0] / 2;
                pc->revives--;
                sprintf(msg, "Used Revive on %s!", pc->party[target]->name.c_str());
                result = 2; // Success
            }
        }
        else if (ch == '3' && isWild && pc->pokeballs > 0) {
            pc->pokeballs--;
            if (pc->party.size() < 6) {
                pc->party.push_back(enemy);
                sprintf(msg, "Caught %s!", enemy->name.c_str());
                result = 100; // Special "Captured" code
            } else {
                sprintf(msg, "Party full! %s fled!", enemy->name.c_str());
                result = -100; // Special "Fled" code
            }
        }

        if (result != 0) {
            clear();
            drawBattleScreen(enemy, isWild ? "Wild:" : "Foe:", activePokemon, "");
            return result; 
        }
    }
}

static int doBattle(Player *pc, Entity *trainer, SinglePokemon *wild) {
    bool isWild = (wild != nullptr);
    size_t pcIndex = 0, npcIndex = 0;
    int fleeAttempts = 0;
    char msg[256] = "";

    while (pcIndex < pc->party.size() && pc->party[pcIndex]->current_hp <= 0) pcIndex++;
    if (pcIndex >= pc->party.size()) {
        if (isWild) delete wild;
        return 0;
    }

    while (true) {
        SinglePokemon *pcP = pc->party[pcIndex];
        SinglePokemon *enP = isWild ? wild : trainer->party[npcIndex];

        drawBattleScreen(enP, isWild ? "Wild:" : "Foe:", pcP, msg);
        mvprintw(9, 2, "1.Fight  2.Bag  3.Run  4.Pokemon");
        refresh();
        msg[0] = 0;
        int ch = getch();
        int pcAction = 0, pcMoveId = -1;

        if (ch == '1') {
            pcMoveId = move_selection_menu(pcP);
            if (pcMoveId != -1) pcAction = 1;
        } else if (ch == '2') {
            pcAction = bag_battle_menu(pc, isWild, enP, pcP, msg);
            if (pcAction == 100) { battle_log(msg); return 1; }
            if (pcAction == -100) { battle_log(msg); delete wild; return 0; }
            drawBattleScreen(enP, isWild ? "Wild:" : "Foe:", pcP, "");
        } else if (ch == '3') {
            if(isWild){
                fleeAttempts++;
                int wildSpeedQuarter = std::max(1, enP->stats[5] / 4) % 256;
                int odds = (pcP->stats[5] * 32 / wildSpeedQuarter) + 30 * fleeAttempts;
                if (rand() % 256 < odds) { battle_log("Got away safely!"); delete wild; return 0; }
                else { battle_log("Couldn't escape!"); pcAction = 2; }
            } else {
                snprintf(msg, sizeof(msg), "Can't run from a Trainer battle!");
            }
        } else if (ch == '4') {
            int next = pickParty(pc, pcIndex, false);
            if (next != -1) { 
                pcIndex = next; 
                pcP = pc->party[pcIndex];
                sprintf(msg, "Go, %s!", pcP->name.c_str());
                pcAction = 2; 
            }
            drawBattleScreen(enP, isWild ? "Wild:" : "Foe:", pcP, "");
        }

        if (pcAction == 0) continue;

        int enMoveId = enP->moves[(enP->moves[1] == -1) ? 0 : rand() % 2];
        
        bool pcFirst = (pcAction >= 2); 
        if (pcAction == 1) {
            int pPrio = 0, ePrio = 0;
            for (auto &m : all_moves) {
                if (m.id == pcMoveId) pPrio = m.priority;
                if (m.id == enMoveId) ePrio = m.priority;
            }
            if (pPrio != ePrio) pcFirst = (pPrio > ePrio);
            else if (pcP->stats[5] != enP->stats[5]) pcFirst = (pcP->stats[5] > enP->stats[5]);
            else pcFirst = (rand() % 2 == 0);
        }

        // Execute Attacks
        for (int i = 0; i < 2; i++) {
            SinglePokemon *atk = (i == 0 && pcFirst) || (i == 1 && !pcFirst) ? pcP : enP;
            SinglePokemon *def = (atk == pcP) ? enP : pcP;
            int mvId = (atk == pcP) ? pcMoveId : enMoveId;

            if (atk->current_hp <= 0) continue;
            if (atk == pcP && pcAction >= 2 && i == 0) { battle_log(msg); msg[0] = 0; continue; }

            int dmg = calcDamage(atk, def, mvId);
            std::string mvName = "Unknown";
            for(auto &m : all_moves) if(m.id == mvId) mvName = m.identifier;

            char log[256];
            if (dmg < 0) sprintf(log, "%s used %s, but it missed!", atk->name.c_str(), mvName.c_str());
            else {
                def->current_hp = std::max(0, def->current_hp - dmg);
                sprintf(log, "%s used %s for %d damage!", atk->name.c_str(), mvName.c_str(), dmg);
            }
            drawBattleScreen(enP, isWild ? "Wild:" : "Foe:", pc->party[pcIndex], log);
            wait_for_key();

            if (def->current_hp <= 0) {
                sprintf(log, "%s fainted!", def->name.c_str());
                battle_log(log);
                if (def == pcP) {
                    int nextIndex = pickParty(pc, (int)pcIndex, true);
                    if (nextIndex == -1) { 
                        if (isWild) delete wild; 
                        return 0; // Blacked out
                    }
                    pcIndex = (size_t)nextIndex;
                    pcP = pc->party[pcIndex];
                    drawBattleScreen(enP, isWild ? "Wild:" : "Foe:", pcP, "");
                    sprintf(log, "Go, %s!", pc->party[pcIndex]->name.c_str());
                    battle_log(log);
                } else {
                    if (isWild) { delete wild; return 1; }
                    if (++npcIndex >= trainer->party.size()) return 1;
                    sprintf(log, "Trainer sent out %s!", trainer->party[npcIndex]->name.c_str());
                    battle_log(log);
                }
                break; 
            }
        }
    }
}
                
void displayEncounter(SinglePokemon *pk, Player *pc) {
    bkgd(COLOR_PAIR(1)); clear(); attrset(COLOR_PAIR(1));
    mvprintw(5, 10, "A wild %s appeared!%s", pk->name.c_str(), pk->shiny ? " It's shiny!" : "");
    mvprintw(7, 10, "Level: %d | HP: %d", pk->level, pk->stats[0]);

    bool anyAlive = false;
    for (auto *p : pc->party) if (p->current_hp > 0) { anyAlive = true; break; }
    if (!anyAlive) {
        mvprintw(9, 10, "All your Pokemon are fainted! The wild Pokemon fled.");
        mvprintw(10, 10, "Visit a Pokemon Center to heal your party.");
        mvprintw(12, 10, "Press any key...");
        refresh(); getch();
        delete pk;
        return;
    }

    mvprintw(9, 10, "Press any key...");
    refresh(); getch();

    doBattle(pc, nullptr, pk);
}

void displayBattle(Entity *npc, Player *pc) {
    const char *name;
    switch (npc->type) {
        case hiker: name = "Hiker"; break;
        case rival: name = "Rival"; break;
        case pacer: name = "Pacer"; break;
        case wanderer: name = "Wanderer"; break;
        case sentry: name = "Sentry"; break;
        case explorer: name = "Explorer"; break;
        default: name = "Trainer"; break;
    }

    bkgd(COLOR_PAIR(1)); clear(); attrset(COLOR_PAIR(1));
    mvprintw(5, 10, "A %s wants to battle!", name);
    mvprintw(7, 10, "They have %zu Pokemon.", npc->party.size());

    bool anyAlive = false;
    for (auto *p : pc->party) if (p->current_hp > 0) { anyAlive = true; break; }
    if (!anyAlive) {
        mvprintw(9, 10, "All your Pokemon are fainted! You can't battle.");
        mvprintw(10, 10, "Visit a Pokemon Center to heal your party.");
        mvprintw(12, 10, "Press any key...");
        refresh(); getch();
        bkgd(COLOR_PAIR(1)); clear();
        return;
    }

    mvprintw(9, 10, "Press any key...");
    refresh(); getch();

    int result = doBattle(pc, npc, nullptr);
    if (result == 1) npc->isDefeated = 1;

    bkgd(COLOR_PAIR(1)); clear();
}


void displayBuilding(char type, Player *pc) {
    bkgd(COLOR_PAIR(1)); clear(); attrset(COLOR_PAIR(1));
 
    if (type == 'C') {
        mvprintw(5, 20, "Welcome to the Pokemon Center!");
        mvprintw(7, 20, "Your Pokemon have been fully healed.");
        for (auto &p : pc->party) p->current_hp = p->stats[0];
    } else {
        mvprintw(5, 20, "Welcome to the PokeMarkt!");
        mvprintw(7, 20, "Supplies restocked: 3 Potions, 2 Revives, 5 Pokeballs.");
        pc->potions = 3;
        pc->revives = 2;
        pc->pokeballs = 5;
    }
 
    mvprintw(9, 20, "Press < to leave.");
    refresh();
    while (getch() != '<');
    bkgd(COLOR_PAIR(1)); clear();
}

void displayBag(Player *pc) {
    char msg[128] = "";
    while (true) {
        bkgd(COLOR_PAIR(1)); clear(); attrset(COLOR_PAIR(1));
        mvprintw(1, 2, "=== Bag ===");
        mvprintw(3, 4, "1. Potion (x%d) - Restore 20 HP", pc->potions);
        mvprintw(4, 4, "2. Revive (x%d) - Revive KO'd Pokemon to half HP", pc->revives);
        mvprintw(5, 4, "   Pokeball (x%d) - Use in wild battles only", pc->pokeballs);
        if (msg[0]) mvprintw(7, 4, "%s", msg);
        mvprintw(9, 4, "0. Back");
        refresh();
        msg[0] = 0;
 
        int ch = getch();
        if (ch == '0') break;
 
        if (ch == '1') { // Potion
            if (pc->potions <= 0) { snprintf(msg, sizeof(msg), "No potions left!"); continue; }
            int targetItem = pickBagTarget(pc, true);
            if (targetItem < 0) continue;
            SinglePokemon *targetPokemon = pc->party[targetItem];
            if (targetPokemon->current_hp >= targetPokemon->stats[0]) {
                snprintf(msg, sizeof(msg), "%s is already at full HP!", targetPokemon->name.c_str()); continue;
            }
            int heal = 20;
            if (targetPokemon->current_hp + heal > targetPokemon->stats[0]) heal = targetPokemon->stats[0] - targetPokemon->current_hp;
            targetPokemon->current_hp += heal;
            pc->potions--;
            snprintf(msg, sizeof(msg), "%s restored %d HP!", targetPokemon->name.c_str(), heal);
 
        } else if (ch == '2') { // Revive
            if (pc->revives <= 0) { snprintf(msg, sizeof(msg), "No revives left!"); continue; }
            int targetItem = pickBagTarget(pc, false);
            if (targetItem < 0) continue;
            SinglePokemon *targetPokemon = pc->party[targetItem];
            targetPokemon->current_hp = targetPokemon->stats[0] / 2;
            pc->revives--;
            snprintf(msg, sizeof(msg), "%s was revived!", targetPokemon->name.c_str());
        }
    }
}

static const int move_costs[7][8] = {
    // Terrain: 0:#, 1:M, 2:C, 3::, 4:., 5:^, 6:*, 7:Default
    {5, 30, 30, 15, 10, 20, 15, INT_MAX}, // Player
    {10, 50, 50, 15, 10, 15, 15, INT_MAX}, // Hiker
    {10, 50, 50, 20, 10, INT_MAX, 15, INT_MAX}, // Rival
    {5, 20, 20, 10, 5, INT_MAX, 10, INT_MAX}, // Pacer
    {10, 50, 50, 15, 10, INT_MAX, 10, INT_MAX}, // Wanderer
    {10, 50, 50, 20, 10, INT_MAX, 15, INT_MAX}, // Sentry (Doesn't really do anything)
    {10, 50, 50, 15, 15, INT_MAX, 10, INT_MAX} // Explorer
};

int getCost(entityType type, char terrain) {
    int terrainIndex;
    // Map the character to a column index
    switch(terrain) {
        case '#': terrainIndex = 0; break; // Path
        case 'M': terrainIndex = 1; break; // Pokemart
        case 'C': terrainIndex = 2; break; // Pokecenter
        case ':': terrainIndex = 3; break; // Tall Grass
        case '.': terrainIndex = 4; break; // Clearing
        case '^': terrainIndex = 5; break; // Trees
        case '*': terrainIndex = 6; break; // Flower
        default:  terrainIndex = 7; break; // INT_MAX
    }

    if (type < 0 || type > 6) return INT_MAX;
    return move_costs[type][terrainIndex];
}

void initializePlayer(Player *pc, singleMap *map){
    pc->type = player;
    // Can only be placed on a path
    int y, x;
    while(1){
        y = rand() % (maxY - 2) + 1;
        x = rand() % (maxX - 2) + 1;
        if(map->terrain[y][x] == '#'){
            pc->y = y;
            pc->x = x;
            pc->standingOn = map->terrain[y][x];
            map->terrain[y][x] = '@';
            break;
        }
    }
}

void displayTrainers(Entity **list, int numTrainers, Player *pc) {
    int quit = 0, scroll_offset = 0;
    while (!quit) {
        bkgd(COLOR_PAIR(1));
        clear();
        attrset(COLOR_PAIR(1));
        mvprintw(0, 0, "%-5s | %-20s", "Type", "Relative Position");
        mvprintw(1, 0, "------------------------------------");

        for (int i = 0; i < 20 && (i + scroll_offset) < numTrainers; i++) {
            Entity *e = list[i + scroll_offset];
            int distY = pc->y - e->y; // Positive = NPC is North of PC
            int distX = pc->x - e->x; // Positive = NPC is West of PC

            mvprintw(i + 2, 0, "%c     | %d %s and %d %s", "@hrpwse"[e->type],
                     abs(distY), (distY >= 0 ? "North" : "South"),
                     abs(distX), (distX >= 0 ? "West" : "East"));
        }
        refresh();
        int ch = getch();
        switch(ch) {
            case 27: quit = 1; break;
            case KEY_UP: if (scroll_offset > 0) scroll_offset--; break;
            case KEY_DOWN: if (scroll_offset < numTrainers - 20) scroll_offset++; break;
        }
    }
}

void pathFinding(singleMap *map, Player *pc, entityType type, int dist[maxY][maxX]){
    heap h;
    heapInitialize(&h);

    for(int i = 0; i < maxY; i++){
        for(int j = 0; j < maxX; j++){
            dist[i][j] = INT_MAX; // Set distances to Int Max.
        }
    }
    // Set player's location to 0 distance.
    dist[pc->y][pc->x] = 0;
    heapPush(&h, nullptr, pc->y, pc->x, 0);

    while(h.size > 0){
        heapNode curr = heapPop(&h);
        if(curr.distance > dist[curr.y][curr.x]) continue;

        // Check the different directions
        for(int dy = -1; dy <= 1; dy++){
            for (int dx = -1; dx <= 1; dx++){
                if(dy == 0 && dx == 0) continue; // Skip the current tile
                int neighborY = curr.y + dy;
                int neighborX = curr.x + dx;

                if(neighborY > 0 && neighborY < maxY - 1 && neighborX > 0 && neighborX < maxX - 1){
                    char terrain = map->terrain[neighborY][neighborX];
                    int moveCost = getCost(type, terrain);
                    if(moveCost != INT_MAX){
                        int newDist = dist[curr.y][curr.x] + moveCost;
                        if(newDist < dist[neighborY][neighborX]){
                            dist[neighborY][neighborX] = newDist;
                            heapPush(&h, nullptr, neighborY, neighborX, newDist);
                        }
                    }
                }
            }
        }
    }
    free(h.nodes);
}

static void placeEntity(singleMap *map, entityType type, int index){
    NPC *npc = new NPC();
    int y = rand() % (maxY - 2) + 1;
    int x = rand() % (maxX - 2) + 1;
    while(getCost(type, map->terrain[y][x]) == INT_MAX || map->terrain[y][x] == 'M' || map->terrain[y][x] == 'C'){
        y = rand() % (maxY - 2) + 1;
        x = rand() % (maxX - 2) + 1;
    }
    npc->y = y;
    npc->x = x;
    npc->type = type;
    npc->standingOn = map->terrain[y][x];
    char dirs[] = {'n', 's', 'e', 'w'};
    npc->direction = dirs[rand() % 4];
    npc->isDefeated = 0;
    switch(type){
        case 1: map->terrain[y][x] = 'h'; break;
        case 2: map->terrain[y][x] = 'r'; break;
        case 3: map->terrain[y][x] = 'p'; break;
        case 4: map->terrain[y][x] = 'w'; break;
        case 5: map->terrain[y][x] = 's'; break;
        case 6: map->terrain[y][x] = 'e'; break;
        default: break;
    }
    map->entityList[index] = npc;
}

void initializeEntities(singleMap *map, int numTrainers, int locationX, int locationY){
    map->entityList = nullptr;
    if (numTrainers <= 0) return;

    map->entityList = (Entity **)malloc(numTrainers * sizeof(Entity *));
    if(!map->entityList) return;

    int dist = abs(locationX - 200) + abs(locationY - 200);
    int index = 0;
    int trainerCount = numTrainers;

    if (numTrainers < 2) {
        if(rand() % 2 == 0) placeEntity(map, hiker, index++);
        else placeEntity(map, rival, index++);
    } else {
        placeEntity(map, hiker, index++);
        placeEntity(map, rival, index++);
        numTrainers -= 2;
        while(numTrainers > 0){
            entityType type = (entityType)(1 + rand() % 6);
            placeEntity(map, type, index++);
            numTrainers--;
        }
    }

    // Pokemon party generation
    for (int i = 0; i < trainerCount; i++) {
        Entity *npc = map->entityList[i];
        npc->party.push_back(new SinglePokemon(calculateLevel(dist)));
        // 60% probability for each subsequent pokemon up to a max of 6
        while (npc->party.size() < 6 && (rand() % 100 < 60)) {
            npc->party.push_back(new SinglePokemon(calculateLevel(dist)));
        }
    }
}

int isCellOccupiedByNPC(Entity **entityList, int numTrainers, int y, int x, Entity *self) {
    for (int i = 0; i < numTrainers; i++) {
        Entity *other = (Entity *)entityList[i];
        if (other == self) continue; // Ignore if self
        if (other->y == y && other->x == x) return 1;
    }
    return 0;
}

void heapInitialize(heap *h){
    h->capacity = 256; // Is increased further
    h->size = 0;
    h->nodes = (heapNode *)malloc(sizeof(heapNode) * h->capacity);
}

void heapPush(heap *h, Entity *e, int y, int x, int distance){
    if (h->size >= h->capacity) {
        h->capacity *= 2;
        h->nodes = (heapNode *)realloc(h->nodes, sizeof(heapNode) * h->capacity);
    }

    int i = h->size++;
    while(i > 0 && h->nodes[(i - 1) / 2].distance > distance){
        h->nodes[i] = h->nodes[(i - 1) / 2];
        i = (i - 1) / 2;
    }
    h->nodes[i].y = y;
    h->nodes[i].x = x;
    h->nodes[i].e = e;
    h->nodes[i].distance = distance;
}

heapNode heapPop(heap *h) {
    heapNode min = h->nodes[0];
    h->size--; 
    
    if (h->size > 0) {
        heapNode last = h->nodes[h->size];
        int i = 0, child;
        while ((child = i * 2 + 1) < h->size) {
            if (child + 1 < h->size && h->nodes[child + 1].distance < h->nodes[child].distance) {
                child++;
            }
            if (last.distance <= h->nodes[child].distance) break;
            h->nodes[i] = h->nodes[child];
            i = child;
        }
        h->nodes[i] = last;
    }
    return min;
}
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <curses.h>
#include <dirent.h>
#include <sys/stat.h>
#include <vector>
#include <string>
#include <algorithm>

#include "map.h"
#include "entity.h"
#include "save.h"

std::vector<Pokemon> all_pokemon;
std::vector<Moves> all_moves;
std::vector<Pokemon_Moves> all_pokemon_moves;
std::vector<Pokemon_Stats> all_pokemon_stats;
std::vector<Pokemon_Types> all_pokemon_types;

struct Game {
    singleMap *world[401][401];
    int x, y, numTrainers;
    Player *pc;
};

static void generateMap(Game *game){
    singleMap *map = game->world[game->y][game->x];
    setupMap(map);

    // Either coordinate of the connecting gate / -1 for randomly generated gate / -2 for no gate (Gates cant be at a -ve value)
    int n = (game->y > 0 && game->world[game->y-1][game->x] != NULL) ? game->world[game->y-1][game->x]->sGate : -1;
    int s = (game->y < 400 && game->world[game->y+1][game->x] != NULL) ? game->world[game->y+1][game->x]->nGate : -1;
    int w = (game->x > 0 && game->world[game->y][game->x-1] != NULL) ? game->world[game->y][game->x-1]->eGate : -1;
    int e = (game->x < 400 && game->world[game->y][game->x+1] != NULL) ? game->world[game->y][game->x+1]->wGate : -1;
    // If the map is on the border dont generate gates at all
    if(game->y == 0) n = -2; 
    if(game->y == 400) s = -2;
    if (game->x == 0) w = -2;
    if (game->x == 400) e = -2;
    generatePaths(map, n, s, w, e);

    int distance = abs(game->x - 200) + abs(game->y - 200);
    int probability = 5; // Default value is 5%
    if(distance < 200) probability = ((-45 * distance) / 200) + 50;
    char pokeMart = ((rand() % 100) < probability || (game->x == 200 && game->y == 200)) ? 'M' : ' ';
    char pokeCentre = ((rand() % 100) < probability || (game->x == 200 && game->y == 200)) ? 'C' : ' ';
    generateBuildings(map, pokeMart, pokeCentre);
    generateTerrain(map);
    initializeEntities(map, game->numTrainers, game->x, game->y);

    for(int i = 0; i < game->numTrainers; i++){
        heapPush(map->turnQueue, map->entityList[i], map->entityList[i]->y, map->entityList[i]->x, 0);
    }
}

static void mapTransition(Game *game, singleMap *&currMap, int newGameY, int newGameX, int entryY, int entryX) {
    Player *pc = game->pc;
    // Remove player from old map terrain
    currMap->terrain[pc->y][pc->x] = pc->standingOn;
    game->y = newGameY;
    game->x = newGameX;

    if (game->world[newGameY][newGameX] == nullptr) {
        game->world[newGameY][newGameX] = new singleMap();
        generateMap(game);
    }
    currMap = game->world[newGameY][newGameX];

    pc->y = entryY;
    pc->x = entryX;
    pc->standingOn = currMap->terrain[entryY][entryX];
    currMap->terrain[entryY][entryX] = '@';

    int minDist = (currMap->turnQueue->size > 0) ? currMap->turnQueue->nodes[0].distance : 0;
    heapPush(currMap->turnQueue, pc, entryY, entryX, minDist);

    pathFinding(currMap, pc, hiker, hikerDistance);
    pathFinding(currMap, pc, rival, rivalDistance);
}

// Assignment 10.2 - Game saving

static void saveGame(Game *game, const std::string &saveName) {
    mkdir("saves", 0755);
    FILE *f = fopen(("saves/" + saveName + ".sav").c_str(), "wb");
    if (!f) return;
    fwrite(&game->x, sizeof(int), 1, f);
    fwrite(&game->y, sizeof(int), 1, f);
    fwrite(&game->numTrainers, sizeof(int), 1, f);
    fwrite(&game->pc->x, sizeof(int), 1, f);
    fwrite(&game->pc->y, sizeof(int), 1, f);
    fwrite(&game->pc->standingOn, sizeof(char), 1, f);
    fwrite(&game->pc->potions, sizeof(int), 1, f);
    fwrite(&game->pc->revives, sizeof(int), 1, f);
    fwrite(&game->pc->pokeballs, sizeof(int), 1, f);
    int partySize = (int)game->pc->party.size();
    fwrite(&partySize, sizeof(int), 1, f);
    for (auto *p : game->pc->party) {
        fwrite(&p->species_id, sizeof(int), 1, f);
        int nameLen = (int)p->name.size();
        fwrite(&nameLen, sizeof(int), 1, f);
        fwrite(p->name.c_str(), 1, nameLen, f);
        fwrite(&p->level, sizeof(int), 1, f);
        fwrite(p->ivs, sizeof(int), 6, f);
        fwrite(p->stats, sizeof(int), 6, f);
        fwrite(p->moves, sizeof(int), 2, f);
        fwrite(&p->current_hp, sizeof(int), 1, f);
        int shiny = p->shiny ? 1 : 0, gender = p->gender ? 1 : 0;
        fwrite(&shiny, sizeof(int), 1, f);
        fwrite(&gender, sizeof(int), 1, f);
    }
    singleMap *currMap = game->world[game->y][game->x];
    // Strip player symbol
    currMap->terrain[game->pc->y][game->pc->x] = game->pc->standingOn;
    // Strip all NPC symbols so saved terrain has clean underlying tiles
    for (int i = 0; i < game->numTrainers; i++) {
        Entity *e = currMap->entityList[i];
        currMap->terrain[e->y][e->x] = e->standingOn;
    }

    fwrite(currMap->terrain, sizeof(char), maxY * maxX, f);

    // Gates
    fwrite(&currMap->nGate, sizeof(int), 1, f);
    fwrite(&currMap->sGate, sizeof(int), 1, f);
    fwrite(&currMap->wGate, sizeof(int), 1, f);
    fwrite(&currMap->eGate, sizeof(int), 1, f);

    // Restore everything after writing
    currMap->terrain[game->pc->y][game->pc->x] = '@';
    char symbols[] = {'@', 'h', 'r', 'p', 'w', 's', 'e'};
    for (int i = 0; i < game->numTrainers; i++) {
        Entity *e = currMap->entityList[i];
        currMap->terrain[e->y][e->x] = symbols[e->type];
    }
    fclose(f);
}

static Game *loadGame(const std::string &saveName, FILE *&outFile) {
    FILE *f = fopen(("saves/" + saveName + ".sav").c_str(), "rb");
    if (!f) return nullptr;
    Game *game = new Game();
    memset(game->world, 0, sizeof(game->world));
    fread(&game->x, sizeof(int), 1, f);
    fread(&game->y, sizeof(int), 1, f);
    fread(&game->numTrainers, sizeof(int), 1, f);
    game->pc = new Player();
    fread(&game->pc->x, sizeof(int), 1, f);
    fread(&game->pc->y, sizeof(int), 1, f);
    fread(&game->pc->standingOn, sizeof(char), 1, f);
    fread(&game->pc->potions, sizeof(int), 1, f);
    fread(&game->pc->revives, sizeof(int), 1, f);
    fread(&game->pc->pokeballs, sizeof(int), 1, f);
    int partySize;
    fread(&partySize, sizeof(int), 1, f);
    for (int i = 0; i < partySize; i++) {
        SinglePokemon *p = new SinglePokemon();
        fread(&p->species_id, sizeof(int), 1, f);
        int nameLen; fread(&nameLen, sizeof(int), 1, f);
        char buf[256] = {}; fread(buf, 1, nameLen, f);
        p->name = std::string(buf);
        fread(&p->level, sizeof(int), 1, f);
        fread(p->ivs, sizeof(int), 6, f);
        fread(p->stats, sizeof(int), 6, f);
        fread(p->moves, sizeof(int), 2, f);
        fread(&p->current_hp, sizeof(int), 1, f);
        int shiny, gender;
        fread(&shiny, sizeof(int), 1, f);
        fread(&gender, sizeof(int), 1, f);
        p->shiny = shiny != 0; p->gender = gender != 0;
        game->pc->party.push_back(p);
    }
    outFile = f;
    return game;
}

static std::vector<std::string> listSaves() {
    std::vector<std::string> saves;
    DIR *dir = opendir("saves");
    if (!dir) return saves;
    struct dirent *entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string fn = entry->d_name;
        if (fn.size() > 4 && fn.substr(fn.size() - 4) == ".sav")
            saves.push_back(fn.substr(0, fn.size() - 4));
    }
    closedir(dir);
    std::sort(saves.begin(), saves.end());
    return saves;
}

static int landingScreen() {
    int selection = 0;
    while (true) {
        clear();
        mvprintw(5, 30, "Pokemon Game");
        mvprintw(8,  30, "%s New Game", selection == 0 ? ">" : " ");
        mvprintw(9,  30, "%s Load Game", selection == 1 ? ">" : " ");
        mvprintw(10, 30, "%s Quit", selection == 2 ? ">" : " ");
        mvprintw(12, 30, "Use Arrow Keys and Enter to select.");
        refresh();
        int ch = getch();
        if (ch == KEY_UP && selection > 0) selection--;
        if (ch == KEY_DOWN && selection < 2) selection++;
        if (ch == '\n' || ch == KEY_ENTER) return selection;
    }
}

static bool loadScreen(std::string &saveName) {
    std::vector<std::string> saves = listSaves();
    if (saves.empty()) {
        clear(); mvprintw(5, 20, "No saves found. Press any key..."); refresh(); getch();
        return false;
    }
    int sel = 0;
    while (true) {
        clear();
        mvprintw(1, 2, "Select a save (ESC to go back):");
        for (int i = 0; i < (int)saves.size(); i++)
            mvprintw(3 + i, 4, "%s %s", i == sel ? ">" : " ", saves[i].c_str());
        refresh();
        int ch = getch();
        if (ch == 27) return false;
        if (ch == KEY_UP && sel > 0) sel--;
        if (ch == KEY_DOWN && sel < (int)saves.size() - 1) sel++;
        if (ch == '\n' || ch == KEY_ENTER) { saveName = saves[sel]; return true; }
    }
}

static void promptSave(Game *game) {
    clear();
    mvprintw(2, 2, "Save name: ");
    refresh();
    echo(); curs_set(1);
    char buf[64] = {};
    getnstr(buf, 63);
    noecho(); curs_set(0);
    if (buf[0] != '\0') {
        saveGame(game, std::string(buf));
        mvprintw(4, 2, "Saved! Press any key..."); refresh(); getch();
    }
}

void runGame(Game *game) {
    singleMap *currMap = game->world[game->y][game->x];
    heapPush(currMap->turnQueue, game->pc, game->pc->y, game->pc->x, 0);
    int quit = 0;
    while (!quit) {
        heapNode top = heapPop(currMap->turnQueue);
        Entity *e = top.e;
        int nextY = e->y;
        int nextX = e->x;
        bool transitioned = false;

        if (e->type == player) {
            renderMap(currMap);
            int turn_done = 0;
            char msg[128];
            snprintf(msg, sizeof(msg), "Location: (%d, %d) | [S]ave [Q]uit [f]ly [t]rainers [>]enter", game->x-200, game->y-200);
            
            while (!turn_done) {
                move(0, 0); 
                clrtoeol();
                mvprintw(0, 0, "%s", msg);
                snprintf(msg, sizeof(msg), "Location: (%d, %d) | [S]ave [Q]uit [f]ly [t]rainers [>]enter", game->x-200, game->y-200);

                int ch = getch();
                int tempY = 0, tempX = 0;

                switch(ch) {
                    case 'Q': quit = 1; turn_done = 1; break;
                    case '7': case 'y': tempY = -1; tempX = -1; break;
                    case '8': case 'k': tempY = -1; tempX = 0;  break;
                    case '9': case 'u': tempY = -1; tempX = 1;  break;
                    case '6': case 'l': tempY = 0;  tempX = 1;  break;
                    case '3': case 'n': tempY = 1;  tempX = 1;  break;
                    case '2': case 'j': tempY = 1;  tempX = 0;  break;
                    case '1': case 'b': tempY = 1;  tempX = -1; break;
                    case '4': case 'h': tempY = 0;  tempX = -1; break;
                    case '5': case ' ': case '.': turn_done = 1; break;
                    case 'S': {
                        promptSave(game);
                        renderMap(currMap);
                        break;
                    }
                    case 't': {
                        displayTrainers(currMap->entityList, game->numTrainers, game->pc);
                        renderMap(currMap);
                        break;
                    }
                    case 'B': { // Bag
                        displayBag(game->pc);
                        renderMap(currMap);
                        break;
                    }
                    case '>':{
                        if (e->standingOn == 'M' || e->standingOn == 'C') {
                            displayBuilding(e->standingOn, game->pc);
                            renderMap(currMap);
                        } else {
                            snprintf(msg, sizeof(msg), "Not standing on a building!");
                        }
                        break;
                    }
                    case 'f':{
                        echo(); curs_set(1);
                        int flyX = 0, flyY = 0;
                        mvprintw(0, 0, "Fly to (x y): ");
                        clrtoeol(); refresh();
                        scanw("%d %d", &flyX, &flyY);
                        noecho(); curs_set(0);

                        if (flyX < -200) flyX = -200;
                        if (flyX > 200) flyX = 200;
                        if (flyY < -200) flyY = -200; 
                        if (flyY > 200) flyY = 200;
                        int newX = flyX + 200, newY = flyY + 200;

                        if (newX == game->x && newY == game->y) {
                            snprintf(msg, sizeof(msg), "Already here!"); break;
                        }
                        // Generate destination if needed so we can find a '#' tile
                        if (game->world[newY][newX] == nullptr) {
                            int savedY = game->y, savedX = game->x;
                            game->y = newY; game->x = newX;
                            game->world[newY][newX] = new singleMap();
                            generateMap(game);
                            game->y = savedY; game->x = savedX;
                        }
                        singleMap *dest = game->world[newY][newX];
                        int randY = rand() % (maxY - 4) + 2;
                        int randX = rand() % (maxX - 4) + 2;
                        while(dest->terrain[randY][randX] != '#'){
                            randY = rand() % (maxY - 4) + 2;
                            randX = rand() % (maxX - 4) + 2;
                        }
                        mapTransition(game, currMap, newY, newX, randY, randX);
                        nextY = e->y; nextX = e->x;
                        transitioned = true;
                        renderMap(currMap);
                        turn_done = 1;
                        break;
                    }
                }

                if (quit) break;

                if (tempY != 0 || tempX != 0) {
                    int newY = e->y + tempY;
                    int newX = e->x + tempX;

                    bool northGate = (newY == 0 && currMap->terrain[0][newX] == '#' && game->y > 0);
                    bool southGate = (newY == maxY-1 && currMap->terrain[maxY-1][newX] == '#' && game->y < 400);
                    bool westGate = (newX == 0 && currMap->terrain[newY][0] == '#' && game->x > 0);
                    bool eastGate = (newX == maxX-1 && currMap->terrain[newY][maxX-1] == '#' && game->x < 400);

                    if (northGate) {
                        mapTransition(game, currMap, game->y-1, game->x, maxY-2, newX);
                        nextY = e->y; nextX = e->x;
                        transitioned = true;
                        renderMap(currMap); turn_done = 1;
                    } else if (southGate) {
                        mapTransition(game, currMap, game->y+1, game->x, 1, newX);
                        nextY = e->y; nextX = e->x; 
                        transitioned = true;
                        renderMap(currMap); turn_done = 1;
                    } else if (westGate) {
                        mapTransition(game, currMap, game->y, game->x-1, newY, maxX-2);
                        nextY = e->y; nextX = e->x;
                        transitioned = true;
                        renderMap(currMap); turn_done = 1;
                    } else if (eastGate) {
                        mapTransition(game, currMap, game->y, game->x+1, newY, 1);
                        nextY = e->y; nextX = e->x;
                        transitioned = true;
                        renderMap(currMap); turn_done = 1;
                    } else if (newY <= 0 || newY >= maxY-1 || newX <= 0 || newX >= maxX-1) {
                        snprintf(msg, sizeof(msg), "The border is impassable!");
                    } else {
                        Entity *target = nullptr;
                        for (int i = 0; i < game->numTrainers; i++) {
                            if (currMap->entityList[i]->y == newY && currMap->entityList[i]->x == newX) target = currMap->entityList[i];
                        }
                        if (target != nullptr) {
                            if (!target->isDefeated) { displayBattle(target, game->pc); renderMap(currMap); }
                            turn_done = 1;
                        } else if (getCost(player, currMap->terrain[newY][newX]) == INT_MAX) {
                            snprintf(msg, sizeof(msg), "The terrain is impassable!");
                        } else {
                            nextY = newY; nextX = newX; turn_done = 1;
                        }
                    }
                }
            }
            if (quit) break;
            // Update NPC Pathfinding after player moves
            pathFinding(currMap, game->pc, hiker, hikerDistance);
            pathFinding(currMap, game->pc, rival, rivalDistance);
            
        } else {           
            // Defeated NPCS stop moving
            if (e->isDefeated) {
                nextY = e->y; 
                nextX = e->x; 
            } else {
                switch (e->type) {
                    case hiker:
                    case rival: {
                        int minDist = INT_MAX;
                        int tempY, tempX;
                        // Check all 8 neighbors in the distance maps
                        for (int moveY = -1; moveY <= 1; moveY++) {
                            for (int moveX = -1; moveX <= 1; moveX++) {
                                if (moveY == 0 && moveX == 0) continue;
                                tempY = e->y + moveY;
                                tempX = e->x + moveX;

                                // Check for the border (this includes gates)
                                if (tempY <= 0 || tempY >= maxY - 1 || tempX <= 0 || tempX >= maxX - 1) continue;

                                int d = (e->type == hiker) ? hikerDistance[tempY][tempX] : rivalDistance[tempY][tempX];
                                if (d < minDist) {
                                    minDist = d;
                                    nextY = tempY;
                                    nextX = tempX;
                                }
                            }
                        }
                        break;
                    }

                    case pacer: {
                        int moveY = e->y + ((e->direction == 'n') ? -1 : (e->direction == 's') ? 1 : 0);
                        int moveX = e->x + ((e->direction == 'w') ? -1 : (e->direction == 'e') ? 1 : 0);
                        
                        // If target is PC, commit to the move and trigger a battle
                        if (moveY == game->pc->y && moveX == game->pc->x) {
                            nextY = moveY;
                            nextX = moveX;
                        }
                        // If blocked by terrain/NPCs/Borders, turn around
                        else if (moveY <= 0 || moveY >= maxY - 1 || moveX <= 0 || moveX >= maxX - 1 ||
                                 getCost(pacer, currMap->terrain[moveY][moveX]) == INT_MAX) {
                            // Reverse direction
                            if (e->direction == 'n') e->direction = 's';
                            else if (e->direction == 's') e->direction = 'n';
                            else if (e->direction == 'e') e->direction = 'w';
                            else e->direction = 'e';
                            // Stay still this turn while turning around
                            nextY = e->y;
                            nextX = e->x;
                        } else {
                            nextY = moveY;
                            nextX = moveX;
                        }
                        break;
                    }

                    case wanderer:
                    case explorer: {
                        int moveY = e->y + ((e->direction == 'n') ? -1 : (e->direction == 's') ? 1 : 0);
                        int moveX = e->x + ((e->direction == 'w') ? -1 : (e->direction == 'e') ? 1 : 0);
                        if (moveY == game->pc->y && moveX == game->pc->x) {
                            nextY = moveY;
                            nextX = moveX;
                        } else {
                            char dirs[] = {'n', 's', 'e', 'w'};
                            int attempts = 0;
                            bool moved = false;
                            while (attempts++ < 12) {
                                int nextMoveY = e->y + ((e->direction == 'n') ? -1 : (e->direction == 's') ? 1 : 0);
                                int nextMoveX = e->x + ((e->direction == 'w') ? -1 : (e->direction == 'e') ? 1 : 0);
                                if (nextMoveY > 0 && nextMoveY < maxY - 1 && nextMoveX > 0 && nextMoveX < maxX - 1) {
                                char newTerrain = currMap->terrain[nextMoveY][nextMoveX];
                                if (getCost(e->type, newTerrain) != INT_MAX &&
                                    (e->type != wanderer || newTerrain == e->standingOn)) {
                                        nextY = nextMoveY;
                                        nextX = nextMoveX;
                                        moved = true;
                                        break;
                                    }
                                }
                                e->direction = dirs[rand() % 4];
                            }
                            if (!moved) {
                                nextY = e->y;
                                nextX = e->x;
                            }
                        }
                        break;
                    }

                    case sentry: {
                        nextY = e->y;
                        nextX = e->x;
                        break;
                    }

                    default: break;
                }
            }
            
            // Collision with player
            if (nextY == game->pc->y && nextX == game->pc->x) {
                if (!e->isDefeated) {
                    displayBattle(e, game->pc); 
                    renderMap(currMap);
                }
                nextY = e->y; nextX = e->x; // Revert
            }
            // Collision with NPC
            else if (isCellOccupiedByNPC((Entity **)currMap->entityList, game->numTrainers, nextY, nextX, e)) {
                nextY = e->y; nextX = e->x; // Revert
            }
        }

        if (transitioned) continue;

        // Update Map and Re-heap
        currMap->terrain[e->y][e->x] = e->standingOn;
        e->y = nextY;
        e->x = nextX;
        e->standingOn = currMap->terrain[e->y][e->x];

        if (e->type == player && (nextY != top.y || nextX != top.x) && e->standingOn == ':') {
            if (rand() % 100 < 10) { // 10% chance in tall grass
                int d = abs(game->x - 200) + abs(game->y - 200);
                displayEncounter(new SinglePokemon(calculateLevel(d)), game->pc);
                renderMap(currMap);
            }
        }

        char symbols[] = {'@', 'h', 'r', 'p', 'w', 's', 'e'};
        currMap->terrain[e->y][e->x] = symbols[e->type];
        int cost = getCost(e->type, e->standingOn);
        heapPush(currMap->turnQueue, e, e->y, e->x, top.distance + cost);
    }
}

int main(int argc, char *argv[]){
    // Parse Data
    all_pokemon = parseFile<Pokemon>("pokemon");
    all_moves = parseFile<Moves>("moves");
    all_pokemon_moves = parseFile<Pokemon_Moves>("pokemon_moves");
    all_pokemon_stats = parseFile<Pokemon_Stats>("pokemon_stats");
    all_pokemon_types = parseFile<Pokemon_Types>("pokemon_types");

    // ncurses
    initscr();
    set_escdelay(0);
    raw();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);

    srand(time(NULL));

    mkdir("saves", 0755);

    int choice = landingScreen();
    if (choice == 2) { endwin(); echo(); curs_set(1); return 0; }

    Game *game = new Game(); 
    game->y = 200;
    game->x = 200;
    game->numTrainers = 10;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--numtrainers") == 0 && i + 1 < argc) {
            game->numTrainers = atoi(argv[++i]);
        }
    }

    if (has_colors()) {
        start_color();
        init_pair(1, COLOR_WHITE, COLOR_BLACK); // Path #, Flowers *
        init_pair(2, COLOR_GREEN, COLOR_BLACK); // Tall grass :
        init_pair(3, COLOR_BLUE, COLOR_BLACK);  // Water ~
        init_pair(4, COLOR_WHITE, COLOR_RED); // Buildings M / C
        init_pair(5, COLOR_MAGENTA, COLOR_BLACK); // boulders %
        init_pair(6, COLOR_YELLOW, COLOR_BLACK); // Trainers h/r/p/w/s/e
        init_pair(7, COLOR_GREEN, COLOR_BLACK); // Trees ^
        init_pair(8, COLOR_YELLOW, COLOR_BLACK); // Clearing .
        init_pair(9, COLOR_WHITE, COLOR_GREEN); // Player @
        bkgd(COLOR_PAIR(1));
    }

    if (choice == 0) {
        // Setup player and starters
        game->pc = new Player();
        selectStarter(game->pc);

        // Generate map
        game->world[game->y][game->x] = new singleMap();
        singleMap *currMap = game->world[game->y][game->x];
        generateMap(game);
        initializePlayer(game->pc, currMap);

        pathFinding(currMap, game->pc, hiker, hikerDistance);
        pathFinding(currMap, game->pc, rival, rivalDistance);
    } else {
        std::string saveName;
        if (!loadScreen(saveName)) { endwin(); echo(); curs_set(1); return 0; }
        FILE *saveFile = nullptr;
        Game *loaded = loadGame(saveName, saveFile);
        if (!loaded) { clear(); mvprintw(5,20,"Failed to load."); refresh(); getch(); endwin(); return 0; }
        delete game;
        game = loaded;
        game->world[game->y][game->x] = new singleMap();
        generateMap(game);
        fread(game->world[game->y][game->x]->terrain, sizeof(char), maxY * maxX, saveFile);
        fread(&game->world[game->y][game->x]->nGate, sizeof(int), 1, saveFile);
        fread(&game->world[game->y][game->x]->sGate, sizeof(int), 1, saveFile);
        fread(&game->world[game->y][game->x]->wGate, sizeof(int), 1, saveFile);
        fread(&game->world[game->y][game->x]->eGate, sizeof(int), 1, saveFile);
        fclose(saveFile);
        singleMap *currMap = game->world[game->y][game->x];
        // Place Player
        int px = game->pc->x, py = game->pc->y;
        if (py>=1 && py<maxY-1 && px>=1 && px<maxX-1 && getCost(player, currMap->terrain[py][px]) != INT_MAX) {
            game->pc->standingOn = currMap->terrain[py][px];
            currMap->terrain[py][px] = '@';
        } else {
            initializePlayer(game->pc, currMap);
        }

        // Place Trainers
        char symbols[] = {'@', 'h', 'r', 'p', 'w', 's', 'e'};
        for (int i = 0; i < game->numTrainers; i++) {
            Entity *e = currMap->entityList[i];
            // If the restored terrain under this trainer is impassable, relocate them
            if (getCost(e->type, currMap->terrain[e->y][e->x]) == INT_MAX ||
                currMap->terrain[e->y][e->x] == 'M' || currMap->terrain[e->y][e->x] == 'C' ||
                currMap->terrain[e->y][e->x] == '@') {
                int ny = rand() % (maxY - 2) + 1;
                int nx = rand() % (maxX - 2) + 1;
                while (getCost(e->type, currMap->terrain[ny][nx]) == INT_MAX ||
                    currMap->terrain[ny][nx] == 'M' || currMap->terrain[ny][nx] == 'C' ||
                    currMap->terrain[ny][nx] == '@' ||
                    isCellOccupiedByNPC(currMap->entityList, i, ny, nx, nullptr)) {
                    ny = rand() % (maxY - 2) + 1;
                    nx = rand() % (maxX - 2) + 1;
                }
                e->y = ny;
                e->x = nx;
            }
            e->standingOn = currMap->terrain[e->y][e->x];
            currMap->terrain[e->y][e->x] = symbols[e->type];
        }
        pathFinding(currMap, game->pc, hiker, hikerDistance);
        pathFinding(currMap, game->pc, rival, rivalDistance);
    }

    runGame(game);

    for (int i = 0; i < 401; i++) {
        for (int j = 0; j < 401; j++) {
            if (!game->world[i][j]) continue;
            if (game->numTrainers > 0) {
                for (int k = 0; k < game->numTrainers; k++)
                    delete game->world[i][j]->entityList[k];
                free(game->world[i][j]->entityList);
            }
            delete game->world[i][j];
        }
    }
    delete game->pc;
    delete game;

    endwin();
    echo();
    curs_set(1);

    return 0;
}
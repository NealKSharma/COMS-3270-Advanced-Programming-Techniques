#include <fstream>
#include <cstdlib>

#include "save.h"

std::vector<std::string> parseLine(const std::string &line){
    std::vector<std::string> ret;
    std::string ch = "";
    for(std::size_t i = 0; i < line.length(); i++){
        if(line[i] == ','){
            ret.push_back(ch);
            ch = "";
        } else {
            ch += line[i];
        }
    }
    ret.push_back(ch);
    return ret;
}

void parseFile(std::string fileName){
    char* home = std::getenv("HOME");
    std::string filePaths[2] = {"/share/cs327/pokedex/pokedex/data/csv/", std::string(home) + "/.poke327/pokedex/pokedex/data/csv/"};

    for(std::size_t i = 0; i < sizeof(filePaths) / sizeof(filePaths[0]); i++){
        std::ifstream file;
        file.open(filePaths[i] + fileName + ".csv");
        if(file.is_open()){
            std::vector<std::string> row;
            std::string line;
            getline(file, line); // Top skip and store the header
            std::string header = line;

            if (fileName == "pokemon"){ // POKEMON CSV
                std::vector<Pokemon> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Pokemon pokemon(row);
                    data.push_back(pokemon);
                }
                // Can do something with this data but I'm just displaying it rightaway
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            } else if (fileName == "moves"){ // MOVES CSV
                std::vector<Moves> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Moves moves(row);
                    data.push_back(moves);
                }
                
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            } else if (fileName == "pokemon_moves"){ // POKEMON_MOVES CSV
                std::vector<Pokemon_Moves> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Pokemon_Moves poke_moves(row);
                    data.push_back(poke_moves);
                }
                
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            } else if (fileName == "pokemon_species"){ // POKEMON_SPECIES CSV
                std::vector<Pokemon_Species> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Pokemon_Species poke_species(row);
                    data.push_back(poke_species);
                }
                
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            } else if (fileName == "experience"){ // EXPERIENCE CSV
                std::vector<Experience> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Experience exp(row);
                    data.push_back(exp);
                }
                
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            } else if (fileName == "type_names"){ // TYPE_NAMES CSV
                std::vector<Type_Names> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Type_Names type_names(row);
                    data.push_back(type_names);
                }
                
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            } else if (fileName == "pokemon_stats"){ // POKEMON_STATS CSV
                std::vector<Pokemon_Stats> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Pokemon_Stats poke_stats(row);
                    data.push_back(poke_stats);
                }
                
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            } else if (fileName == "stats"){ // STATS CSV
                std::vector<Stats> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Stats stats(row);
                    data.push_back(stats);
                }
                
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            } else if (fileName == "pokemon_types"){ // POKEMON_TYPES CSV
                std::vector<Pokemon_Types> data;
                while(getline(file, line)){
                    row = parseLine(line);
                    Pokemon_Types poke_types(row);
                    data.push_back(poke_types);
                }
                
                std::cout << header << std::endl;
                for(std::size_t i = 0; i < data.size(); i++){
                    data[i].display();
                }
            }
            break;
        }
        else {
            std::cout << "File not found in location: "<< filePaths[i] << fileName << ".csv" << std::endl;
        }
    }
}
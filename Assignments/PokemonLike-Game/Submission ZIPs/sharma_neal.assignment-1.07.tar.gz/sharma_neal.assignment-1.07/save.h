#ifndef SAVE_H
#define SAVE_H

#include <string>
#include <vector>
#include <climits>
#include <iostream>

inline int toInt(const std::string &str){
    return str.empty() ? INT_MAX : std::stoi(str);
}

inline void printInt(int num, char comma = ','){
   if (num != INT_MAX) std::cout << num;
   std::cout << comma;
}

class Pokemon {
    public:
     int id;
     std::string identifier;
     int species_id, height, weight, base_experience, order, is_default;

     Pokemon(std::vector<std::string> &row){
        id = toInt(row[0]);
        identifier = row[1];
        species_id = toInt(row[2]);
        height = toInt(row[3]); 
        weight = toInt(row[4]);
        base_experience = toInt(row[5]);
        order = toInt(row[6]);
        is_default = toInt(row[7]);
     }

     void display() const{
         printInt(id);
         std::cout << identifier << ",";
         printInt(species_id);
         printInt(height);
         printInt(weight);
         printInt(base_experience); 
         printInt(order); 
         printInt(is_default, '\n');
     }
};

class Moves {
    public:
     int id;
     std::string identifier;
     int generation_id, type_id, power, pp, accuracy, priority, target_id,damage_class_id, 
         effect_id, effect_chance, contest_type_id,contest_effect_id, super_contest_effect_id;

     Moves(std::vector<std::string> &row){
        id = toInt(row[0]);
        identifier = row[1];
        generation_id = toInt(row[2]);
        type_id = toInt(row[3]);
        power = toInt(row[4]);
        pp = toInt(row[5]);
        accuracy = toInt(row[6]);
        priority = toInt(row[7]);
        target_id = toInt(row[8]);
        damage_class_id = toInt(row[9]);
        effect_id = toInt(row[10]);
        effect_chance = toInt(row[11]);
        contest_type_id = toInt(row[12]);
        contest_effect_id = toInt(row[13]);
        super_contest_effect_id = toInt(row[14]);
     }

     void display() const{
         printInt(id);
         std::cout << identifier << ",";
         printInt(generation_id);
         printInt(type_id);
         printInt(power);
         printInt(pp);
         printInt(accuracy);
         printInt(priority);
         printInt(target_id);
         printInt(damage_class_id);
         printInt(effect_id);
         printInt(effect_chance);
         printInt(contest_type_id);
         printInt(contest_effect_id);
         printInt(super_contest_effect_id, '\n');
     }
};

class Pokemon_Moves {
    public:
     int pokemon_id, version_group_id, move_id, pokemon_move_method_id, level, order;

     Pokemon_Moves(std::vector<std::string> &row){
        pokemon_id = toInt(row[0]);
        version_group_id = toInt(row[1]);
        move_id = toInt(row[2]);
        pokemon_move_method_id = toInt(row[3]);
        level = toInt(row[4]);
        order = toInt(row[5]);
     }

     void display() const{
         printInt(pokemon_id); 
         printInt(version_group_id); 
         printInt(move_id); 
         printInt(pokemon_move_method_id); 
         printInt(level); 
         printInt(order, '\n'); 
     }
};

class Pokemon_Species {
    public:
     int id;
     std::string identifier;
     int generation_id, evolves_from_species_id, evolution_chain_id, color_id, shape_id, habitat_id, gender_rate,
         capture_rate, base_happiness, is_baby, hatch_counter, has_gender_differences, growth_rate_id, forms_switchable,
         is_legendary, is_mythical, order, conquest_order;

     Pokemon_Species(std::vector<std::string> &row){
        id = toInt(row[0]);
        identifier = row[1];
        generation_id = toInt(row[2]);
        evolves_from_species_id = toInt(row[3]);
        evolution_chain_id = toInt(row[4]);
        color_id = toInt(row[5]);
        shape_id = toInt(row[6]);
        habitat_id = toInt(row[7]);
        gender_rate = toInt(row[8]);
        capture_rate = toInt(row[9]);
        base_happiness = toInt(row[10]);
        is_baby = toInt(row[11]);
        hatch_counter = toInt(row[12]);
        has_gender_differences = toInt(row[13]);
        growth_rate_id = toInt(row[14]);
        forms_switchable = toInt(row[15]);
        is_legendary = toInt(row[16]);
        is_mythical = toInt(row[17]);
        order = toInt(row[18]);
        conquest_order = toInt(row[19]);
     }

     void display() const{
         printInt(id); 
         std::cout << identifier << ",";
         printInt(generation_id); 
         printInt(evolves_from_species_id); 
         printInt(evolution_chain_id); 
         printInt(color_id); 
         printInt(shape_id); 
         printInt(habitat_id); 
         printInt(gender_rate); 
         printInt(capture_rate); 
         printInt(base_happiness); 
         printInt(is_baby); 
         printInt(hatch_counter); 
         printInt(has_gender_differences); 
         printInt(growth_rate_id); 
         printInt(forms_switchable); 
         printInt(is_legendary); 
         printInt(is_mythical); 
         printInt(order); 
         printInt(conquest_order, '\n'); 
     }
};

class Experience {
    public:
     int growth_rate_id, level, experience;

     Experience(std::vector<std::string> &row){
        growth_rate_id = toInt(row[0]);
        level = toInt(row[1]);
        experience = toInt(row[2]);
     }

     void display() const{
         printInt(growth_rate_id); 
         printInt(level); 
         printInt(experience, '\n'); 
     }
};

class Type_Names {
    public:
     int type_id, local_language_id;
     std::string name;

     Type_Names(std::vector<std::string> &row){
        type_id = toInt(row[0]);
        local_language_id = toInt(row[1]);
        name = row[2];
     }
     
     void display() const{
         printInt(type_id); 
         printInt(local_language_id); 
         std::cout << name << std::endl;
     }
};

class Pokemon_Stats {
    public:
     int pokemon_id, stat_id, base_stat, effort;

     Pokemon_Stats(std::vector<std::string> &row){
        pokemon_id = toInt(row[0]);
        stat_id = toInt(row[1]);
        base_stat = toInt(row[2]);
        effort = toInt(row[3]);
     }

     void display() const{
         printInt(pokemon_id); 
         printInt(stat_id);
         printInt(base_stat);
         printInt(effort, '\n'); 
     }
};

class Stats {
    public:
     int id, damage_class_id;
     std::string identifier;
     int is_battle_only, game_index;

     Stats(std::vector<std::string> &row){
        id = toInt(row[0]);
        damage_class_id = toInt(row[1]);
        identifier = row[2];
        is_battle_only = toInt(row[3]);
        game_index = toInt(row[4]);
     }

     void display() const{
         printInt(id); 
         printInt(damage_class_id);
         std::cout << identifier << ',';
         printInt(is_battle_only);
         printInt(game_index, '\n'); 
     }
};

class Pokemon_Types {
    public:
     int pokemon_id, type_id, slot;

     Pokemon_Types(std::vector<std::string> &row){
        pokemon_id = toInt(row[0]);
        type_id = toInt(row[1]);
        slot = toInt(row[2]);
     }

     void display() const{
         printInt(pokemon_id); 
         printInt(type_id); 
         printInt(slot, '\n'); 
     }
};

void parseFile(std::string fileName);

#endif